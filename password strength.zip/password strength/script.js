let password = document.querySelector(".passInput");
let message = document.querySelector(".message");
let word = document.querySelector(".word");

password.addEventListener("input",()=>{
    let hasSpecailCharacter = /[@#$%^&*]+/.test(password.value)

    if(password.value.length > 0){
        word.innerHTML = "weak"
        message.style.display = "block";
        password.style.borderColor = "#e24848"
        message.style.color = "#e24848"
    }if(password.value.length >= 4 && password.value.length < 8 && hasSpecailCharacter){
        word.innerHTML = "medium"
        password.style.borderColor = "#e5e763d3"
        message.style.color = "#e5e763d3"
    }if(password.value.length >= 8 && hasSpecailCharacter){
        word.innerHTML = "strong"
        password.style.borderColor = "#5d995bd3"
        message.style.color = "#5d995bd3"
    }else if(password.value.length === 0){
        password.style.borderColor = "#ffffffd3"
        message.style.display = "none";
    }
    
})
